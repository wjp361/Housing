package com.housing.common.beanvalidator;

/**
 * 默认Bean验证组
 * @author ThinkGem
 */
public interface DefaultGroup {

}
