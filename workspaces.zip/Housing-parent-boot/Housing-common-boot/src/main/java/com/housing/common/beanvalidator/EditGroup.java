package com.housing.common.beanvalidator;

/**
 * 编辑Bena验证组
 * @author ThinkGem
 */
public interface EditGroup {

}
